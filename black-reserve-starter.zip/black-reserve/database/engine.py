from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase

from config.settings import settings


class Base(DeclarativeBase):
    pass


engine = create_async_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db():
    from database.models import (
        User, Admin, District, Product, ProductPosition, Order,
        Review, BalanceTopup, Payment, ActionLog
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
