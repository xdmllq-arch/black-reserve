from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str = ""
    database_url: str = "postgresql+asyncpg://blackreserve:blackreserve@localhost:5432/blackreserve"
    redis_url: str = "redis://localhost:6379/0"
    admin_ids: str = "5356069195,8336765971,7803163835"
    bot_name: str = "BLACK RESERVE"
    support_username: str = "J_Stat"
    operator_username: str = ""
    ltc_wallet: str = "LYqbDYDAYcB1Pc5F7C59toNQcMJaMWmj2c"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def admin_id_set(self) -> set[int]:
        return {
            int(value.strip())
            for value in self.admin_ids.split(",")
            if value.strip()
        }


settings = Settings()
