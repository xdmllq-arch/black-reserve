from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def client_main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🛒 Купить"), KeyboardButton(text="📦 Мои заказы")],
            [KeyboardButton(text="💰 Баланс"), KeyboardButton(text="🔄 Обменники")],
            [KeyboardButton(text="⭐ Отзывы"), KeyboardButton(text="👤 Личный кабинет")],
            [KeyboardButton(text="🛟 Саппорт"), KeyboardButton(text="👨‍💻 Оператор")],
        ],
        resize_keyboard=True,
        input_field_placeholder="Выберите раздел",
    )
