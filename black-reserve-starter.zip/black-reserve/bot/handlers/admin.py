from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from config.settings import settings

router = Router()


def is_admin(telegram_id: int) -> bool:
    return telegram_id in settings.admin_id_set


@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not message.from_user or not is_admin(message.from_user.id):
        await message.answer("⛔ Доступ запрещён.")
        return

    await message.answer(
        "🖤 <b>BLACK RESERVE ADMIN</b>\n\n"
        "Панель управления проектом.\n\n"
        "👤 Админ подтверждён по Telegram ID."
    )
