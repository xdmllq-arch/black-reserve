from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from sqlalchemy import select

from database.engine import SessionLocal
from database.models import User
from bot.keyboards.main import client_main_menu

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    tg_user = message.from_user

    async with SessionLocal() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == tg_user.id)
        )
        user = result.scalar_one_or_none()

        if user is None:
            user = User(
                telegram_id=tg_user.id,
                username=tg_user.username,
            )
            session.add(user)
        else:
            user.username = tg_user.username

        await session.commit()

    text = (
        "🖤 <b>BLACK RESERVE</b>\n\n"
        "Добро пожаловать.\n\n"
        "Выберите нужный раздел ниже."
    )

    await message.answer(text, reply_markup=client_main_menu())
