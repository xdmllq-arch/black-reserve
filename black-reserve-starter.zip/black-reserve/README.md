# BLACK RESERVE — starter project

Стартовый каркас Telegram-бота BLACK RESERVE.

## Что уже есть
- Python 3.12
- aiogram 3
- PostgreSQL + SQLAlchemy async
- Redis
- `/start`
- клиентское меню
- регистрация/обновление пользователя по Telegram ID
- проверка админов по Telegram ID
- `/admin`
- базовые модели БД

## Администраторы
- 5356069195
- 8336765971
- 7803163835

## Запуск локально

1. Скопируйте `.env.example` в `.env`.
2. Вставьте токен BotFather в `BOT_TOKEN`.
3. Запустите:

```bash
docker compose up --build
```

Или установите зависимости вручную:

```bash
pip install -r requirements.txt
python main.py
```

Токен бота никогда не публикуйте в коде или чате.
