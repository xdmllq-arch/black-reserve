import sqlite3
from datetime import datetime
DB = "black_reserve.db"

def conn(): return sqlite3.connect(DB)
def init_db():
    c=conn(); x=c.cursor()
    x.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT, balance_usd REAL DEFAULT 0, created_at TEXT)")
    x.execute("CREATE TABLE IF NOT EXISTS deposits (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount_usd REAL, amount_ltc REAL, address TEXT, status TEXT DEFAULT 'pending', txid TEXT, created_at TEXT, processed_at TEXT)")
    c.commit(); c.close()
def upsert_user(uid, username, full_name):
    c=conn(); c.execute("INSERT INTO users(user_id,username,full_name,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,full_name=excluded.full_name",(uid,username,full_name,datetime.utcnow().isoformat())); c.commit(); c.close()
def get_user(uid):
    c=conn(); r=c.execute("SELECT * FROM users WHERE user_id=?",(uid,)).fetchone(); c.close(); return r
def create_deposit(uid, usd, ltc, address):
    c=conn(); r=c.execute("INSERT INTO deposits(user_id,amount_usd,amount_ltc,address,created_at) VALUES(?,?,?,?,?)",(uid,usd,ltc,address,datetime.utcnow().isoformat())); c.commit(); i=r.lastrowid; c.close(); return i
def approve_deposit(dep_id):
    c=conn(); r=c.execute("SELECT user_id,amount_usd,status FROM deposits WHERE id=?",(dep_id,)).fetchone()
    if not r or r[2] != 'pending': c.close(); return None
    c.execute("UPDATE deposits SET status='approved',processed_at=? WHERE id=?",(datetime.utcnow().isoformat(),dep_id)); c.execute("UPDATE users SET balance_usd=balance_usd+? WHERE user_id=?",(r[1],r[0])); c.commit(); c.close(); return r[0],r[1]
def reject_deposit(dep_id):
    c=conn(); r=c.execute("SELECT status FROM deposits WHERE id=?",(dep_id,)).fetchone()
    if not r or r[0] != 'pending': c.close(); return False
    c.execute("UPDATE deposits SET status='rejected',processed_at=? WHERE id=?",(datetime.utcnow().isoformat(),dep_id)); c.commit(); c.close(); return True
