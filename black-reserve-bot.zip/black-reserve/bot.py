import asyncio
import os
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from dotenv import load_dotenv
from db import init_db, upsert_user, get_user, create_deposit, approve_deposit, reject_deposit
from keyboards import main_kb, admin_deposit_kb
from services.ltc import get_ltc_usd_price, get_incoming_transactions

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
LTC_DEPOSIT_ADDRESS = os.getenv("LTC_DEPOSIT_ADDRESS", "")

bot = Bot(BOT_TOKEN)
dp = Dispatcher()
waiting_amount = set()
seen_txids = set()

@dp.message(CommandStart())
async def start(message: Message):
    upsert_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    await message.answer("🖤 <b>BLACK RESERVE</b>\n\nДобро пожаловать.", reply_markup=main_kb(), parse_mode="HTML")

@dp.message(F.text == "💰 Баланс")
async def balance(message: Message):
    user = get_user(message.from_user.id)
    balance = user[3] if user else 0
    await message.answer(f"💰 Ваш баланс: <b>${balance:.2f}</b>", parse_mode="HTML")

@dp.message(F.text == "📥 Пополнить LTC")
async def deposit_start(message: Message):
    waiting_amount.add(message.from_user.id)
    await message.answer("Введите сумму пополнения в USD, например: <b>100</b>", parse_mode="HTML")

@dp.message()
async def amount(message: Message):
    uid = message.from_user.id
    if uid not in waiting_amount:
        return
    try:
        usd = float(message.text.replace(",", ".").strip())
        if usd <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Введите корректную сумму, например 100")
        return
    waiting_amount.discard(uid)
    try:
        price = await get_ltc_usd_price()
        ltc = usd / price
        dep_id = create_deposit(uid, usd, ltc, LTC_DEPOSIT_ADDRESS)
        await message.answer(
            f"🖤 <b>Заявка #{dep_id}</b>\n\nСумма: <b>${usd:.2f}</b>\nК оплате: <b>{ltc:.8f} LTC</b>\n\nАдрес:\n<code>{LTC_DEPOSIT_ADDRESS}</code>\n\nПосле поступления LTC администратор проверит платеж и вручную зачислит USD.",
            parse_mode="HTML"
        )
        await bot.send_message(ADMIN_ID, f"📥 Новая заявка #{dep_id}\n👤 ID: {uid}\n💵 ${usd:.2f}\nŁ {ltc:.8f}", reply_markup=admin_deposit_kb(dep_id))
    except Exception as e:
        await message.answer("Не удалось создать заявку. Попробуйте позже.")
        print("deposit error:", e)

@dp.callback_query(F.data.startswith("admin_approve:"))
async def approve(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("Нет доступа", show_alert=True); return
    dep_id = int(call.data.split(":")[1])
    result = approve_deposit(dep_id)
    if not result:
        await call.answer("Заявка уже обработана", show_alert=True); return
    user_id, usd = result
    await bot.send_message(user_id, f"✅ Пополнение #{dep_id} подтверждено. Зачислено <b>${usd:.2f}</b>.", parse_mode="HTML")
    await call.message.edit_text(f"✅ Заявка #{dep_id} подтверждена. Зачислено ${usd:.2f}.")
    await call.answer("Подтверждено")

@dp.callback_query(F.data.startswith("admin_reject:"))
async def reject(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("Нет доступа", show_alert=True); return
    dep_id = int(call.data.split(":")[1])
    if not reject_deposit(dep_id):
        await call.answer("Заявка уже обработана", show_alert=True); return
    await call.message.edit_text(f"❌ Заявка #{dep_id} отклонена.")
    await call.answer("Отклонено")

async def ltc_watcher():
    while True:
        try:
            txs = await get_incoming_transactions(LTC_DEPOSIT_ADDRESS)
            for tx in txs:
                txid = tx.get("txid")
                if txid and txid not in seen_txids:
                    seen_txids.add(txid)
                    await bot.send_message(ADMIN_ID, f"🚨 <b>Обнаружен входящий LTC</b>\nTX: <code>{txid}</code>\nСумма: {tx.get('amount_ltc', 0):.8f} LTC\n\nПроверьте транзакцию и подтвердите нужную заявку вручную.", parse_mode="HTML")
        except Exception as e:
            print("LTC watcher error:", e)
        await asyncio.sleep(60)

async def main():
    init_db()
    asyncio.create_task(ltc_watcher())
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
