import aiohttp
async def get_ltc_usd_price():
    async with aiohttp.ClientSession() as s:
        async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd", timeout=15) as r:
            r.raise_for_status(); return float((await r.json())["litecoin"]["usd"])
async def get_incoming_transactions(address):
    url=f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/full?limit=10"
    async with aiohttp.ClientSession() as s:
        async with s.get(url, timeout=20) as r:
            r.raise_for_status(); data=await r.json()
    out=[]
    for tx in data.get("txs",[]):
        total=sum(v.get("value",0) for v in tx.get("outputs",[]) if address in v.get("addresses",[]))
        if total>0: out.append({"txid":tx.get("hash"),"amount_ltc":total/100_000_000})
    return out
