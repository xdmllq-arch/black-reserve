from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
def main_kb(): return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="💰 Баланс")],[KeyboardButton(text="📥 Пополнить LTC")]], resize_keyboard=True)
def admin_deposit_kb(i): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Подтвердить",callback_data=f"admin_approve:{i}"),InlineKeyboardButton(text="❌ Отклонить",callback_data=f"admin_reject:{i}")]])
